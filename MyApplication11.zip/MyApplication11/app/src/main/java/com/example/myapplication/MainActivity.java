package com.example.myapplication;


import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {

    public static final int LOCATION_REQUEST_CODE = 5;
    private TextView locationTV;
    private String locationProvider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationTV = findViewById(R.id.location_tv);


        String[] permissions = {android.Manifest.permission.ACCESS_FINE_LOCATION,};
        //check if we have permission for the position
        // if not request the permission
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, permissions, LOCATION_REQUEST_CODE);

        } else {
            //all ok we have permission continue with the app.
            //we need location service.
            String locationService = Context.LOCATION_SERVICE;
            // we need service provider
            String serviceProvider = LocationManager.GPS_PROVIDER;
            // we need a location manadger
            LocationManager locationManager = (LocationManager) getSystemService(locationService);

            Location location = locationManager.getLastKnownLocation(serviceProvider);



            Criteria criteria = new Criteria();
            criteria.setAccuracy(criteria.ACCURACY_FINE);
            criteria.setAltitudeRequired(false);
            criteria.setBearingRequired(false);
            criteria.setCostAllowed(true);

            locationProvider = locationManager.getBestProvider(criteria,true);
            locationManager.requestLocationUpdates(locationProvider,2000,2,listener);


        }

    }
    private LocationListener listener = new LocationListener() {
        @Override
        public void onLocationChanged(@NonNull Location location) {
            displayPosition(location);
        }
        @Override
        public void onStatusChanged(String provider,int status,Bundle extras){}
        @Override
        public void onProviderEnabled(@NonNull String provider){}
        @Override
        public void onProviderDisabled(@NonNull String provider){}
    };

    private void displayPosition(Location location) {
        if(location!= null){
            String message = String.format(
                    "Latitude :%f\nLongitude : %f",location.getLatitude(),location.getLongitude()
            );
            locationTV.setText(message);
        }else {
            locationTV.setText("Something went wrong!.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_REQUEST_CODE
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            //user granted location permission
            recreate();
        } else {
            //user denied location permission
            Toast.makeText(this, "THIS APP requires Location Service", Toast.LENGTH_LONG).show();
            finishAndRemoveTask();
        }

    }

}