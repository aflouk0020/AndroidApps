package com.example.my_application1;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listview;
    //ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //progressBar = findViewById(R.id.progressBar); // Initialize progressBar
        listview = findViewById(R.id.listview);

        // List of programming languages
        ArrayList<String> programmingLanguages = new ArrayList<>();
        programmingLanguages.add("C");
        programmingLanguages.add("Python");
        programmingLanguages.add("Java");
        programmingLanguages.add("C++");
        programmingLanguages.add("C#");
        programmingLanguages.add("Visual Basic");
        programmingLanguages.add("Java Script");
        programmingLanguages.add("PHP");
        programmingLanguages.add("R");
        programmingLanguages.add("SQL");
        programmingLanguages.add("Fortran");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                programmingLanguages
        );

        listview.setAdapter(adapter);

        // Set on item click listener for the ListView
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedLanguage = programmingLanguages.get(position);
                Intent intent;
                switch (selectedLanguage) {
                    case "C":
                        intent = new Intent(MainActivity.this, CLanguage.class);
                        intent.putExtra("languageName", "C Language");
                        intent.putExtra("showProgressBar", true);
                        break;
                    case "Python":
                        intent = new Intent(MainActivity.this, PythonLanguage.class);
                        intent.putExtra("languageName", "Python");
                        intent.putExtra("showProgressBar", true);
                        break;
                    case "Java":
                        intent = new Intent(MainActivity.this, JavaLanguage.class);
                        intent.putExtra("languageName", "Java");
                        intent.putExtra("showProgressBar", true);
                        break;
                    case "C++":
                        intent = new Intent(MainActivity.this, CPlusPlusLanguage.class);
                        intent.putExtra("languageName", "C++");
                        intent.putExtra("showProgressBar", true);

                        break;
                    case "C#":
                        intent = new Intent(MainActivity.this, CSharpLanguage.class);
                        intent.putExtra("languageName", "C#");
                        intent.putExtra("showProgressBar", true);
                        break;
                    case "Visual Basic":
                        intent = new Intent(MainActivity.this, VisualBasicLanguage.class);
                        intent.putExtra("languageName", "Visual Basic");
                        intent.putExtra("showProgressBar", true);
                        break;
                    case "Java Script":
                        intent = new Intent(MainActivity.this, JavaScriptLanguage.class);
                        intent.putExtra("languageName", "Java Script");
                        intent.putExtra("showProgressBar", true);
                        break;
                    case "PHP":
                        intent = new Intent(MainActivity.this, PHPLanguage.class);
                        intent.putExtra("languageName", "PHP");
                        intent.putExtra("showProgressBar", true);
                        break;
                    case "R":
                        intent = new Intent(MainActivity.this, RLanguage.class);
                        intent.putExtra("languageName", "R");
                        intent.putExtra("showProgressBar", true);
                        break;
                    case "SQL":
                        intent = new Intent(MainActivity.this, SQLLanguage.class);
                        intent.putExtra("languageName", "SQL");
                        intent.putExtra("showProgressBar", true);
                        break;
                    case "Fortran":
                        intent = new Intent(MainActivity.this, FortranLanguage.class);
                        intent.putExtra("languageName", "Fortran");
                        intent.putExtra("showProgressBar", true);
                        break;
                    default:
                        return; // Do nothing if no valid selection
                }

                startActivity(intent); // Start the new activity
            }
        });
    }
}
