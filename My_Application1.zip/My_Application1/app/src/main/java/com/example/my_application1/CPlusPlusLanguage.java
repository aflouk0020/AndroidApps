//package com.example.my_application1;
//
//import android.os.Bundle;
//import android.view.View;
//import android.widget.ProgressBar;
//import android.widget.TextView;
//
//import androidx.activity.EdgeToEdge;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.graphics.Insets;
//import androidx.core.view.ViewCompat;
//import androidx.core.view.WindowInsetsCompat;
//
//import java.util.Timer;
//import java.util.TimerTask;
//
//public class CPlusPlusLanguage extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//
//    }
//}
package com.example.my_application1;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class CPlusPlusLanguage extends AppCompatActivity {
    ProgressBar progressBar;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cplus_plus_language);
        String languageName = getIntent().getStringExtra("languageName");

        // Retrieve the showProgressBar extra
        boolean showProgressBar = getIntent().getBooleanExtra("showProgressBar", false);

        progressBar = findViewById(R.id.progressBar);
        textView = findViewById(R.id.textView);

        // Control progress bar visibility based on the extra
        if (showProgressBar) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }

        textView.setVisibility(View.GONE);

        new Timer().schedule(new TimerTask() {
            int counter = 0;

            @Override
            public void run() {
                runOnUiThread(() -> {
                    counter++;
                    progressBar.setProgress(counter);
                    if (counter == 100) {
                        progressBar.setVisibility(View.GONE);
                        textView.setVisibility(View.VISIBLE);
                        textView.setText(languageName);
                        cancel();
                    }
                });
            }
        }, 0, 100);
    }
}