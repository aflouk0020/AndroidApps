package com.example.project_4_demo;

import android.os.Bundle;
import android.widget.Toast; // Import Toast

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);

        String username = getIntent().getStringExtra("USERNAME"); // Get username
        Toast.makeText(HomeActivity.this, "Welcome back " + username, Toast.LENGTH_SHORT).show(); // Display Toast
    }
}