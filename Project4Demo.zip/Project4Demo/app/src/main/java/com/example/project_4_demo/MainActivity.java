package com.example.project_4_demo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button butSignIn, butCreateAccount;
    EditText etUsername, etPassword;
    DBAccess db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        db = new DBAccess(this);
        butSignIn = findViewById(R.id.but_sign_in);
        etUsername = findViewById(R.id.username);
        etPassword = findViewById(R.id.password);
        butCreateAccount = findViewById(R.id.but_create_account);

        butCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        butSignIn.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            // Check username length
            if (username.length() < 3) {
                Toast.makeText(MainActivity.this, "Username must be at least 3 Characters", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check password length
            if (password.length() < 8) {
                Toast.makeText(MainActivity.this, "Password must be at least 8 Characters", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isSignedIn = db.checkUser(username, password); // Use validated username and password
            if (isSignedIn) {
                Toast.makeText(MainActivity.this, "Sign-in successful!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                intent.putExtra("USERNAME", username); // Pass validated username
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "Sign-in failed. Please check your credentials.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}