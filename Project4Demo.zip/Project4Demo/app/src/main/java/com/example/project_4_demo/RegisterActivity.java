package com.example.project_4_demo;


import android.content.Intent; // Added import statement
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText etUsername, etPassword, etRepeatPassword;
    private Button butRegister, butSignIn;
    private DBAccess db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etUsername = findViewById(R.id.username);
        etPassword = findViewById(R.id.password);
        etRepeatPassword = findViewById(R.id.et_repeat_password);
        butRegister = findViewById(R.id.but_register);
        butSignIn = findViewById(R.id.but_sign_in);

        db = new DBAccess(this);

        butSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle sign-in logic here
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        butRegister.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String repeatPassword = etRepeatPassword.getText().toString().trim();
            if (username.length() < 3) {
                Toast.makeText(RegisterActivity.this, "Username must be at least 3 Characters", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check password length
            if (password.length() < 8) {
                Toast.makeText(RegisterActivity.this, "Password must be at least 8 Characters", Toast.LENGTH_SHORT).show();
                return;
            }
            if (username.isEmpty() || password.isEmpty() || repeatPassword.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
                return; // Exit if fields are empty
            }

            if (!password.equals(repeatPassword)) {
                Toast.makeText(RegisterActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return; // Exit if passwords don't match
            }

            if (db.checkUsername(username)) {
                Toast.makeText(RegisterActivity.this, "Username already exists", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean inserted = db.insertUser(username, password);
            if (inserted) {
                Toast.makeText(RegisterActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                etUsername.setText("");
                etPassword.setText("");
                etRepeatPassword.setText(""); // Clear repeat password field as well
            } else {
                Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
