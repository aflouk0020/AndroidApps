package com.example.mymqttapplication;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    private Context context;
    private MqttAsyncClient mqttAsyncClient;
    private String broker = "tcp://192.168.0.102:1883";
    private TextView ramTextView;
    private TextView storageTextView;
    private String clientID;
    private static final String TOPIC = "inclass/Example";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        clientID = MqttAsyncClient.generateClientId();
        context = this;

        ramTextView = findViewById(R.id.ram_tv);
        storageTextView = findViewById(R.id.storage_tv);

        Button sendButton = findViewById(R.id.message_btn);
        sendButton.setOnClickListener(this::sendMessage);
    }

    @Override
    protected void onResume() {
        super.onResume();
        connectMqtt();
    }

    protected void onPause() {
        super.onPause();
        try {
            mqttAsyncClient.disconnect();
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    private MqttCallback mqttCallBack = new MqttCallback() {
        @Override
        public void connectionLost(Throwable cause) {
        }

        @Override
        public void messageArrived(String topic, MqttMessage message) throws Exception {
            if (topic.equals(TOPIC)) {
                String strMessage = new String(message.getPayload(), StandardCharsets.UTF_8);
                // Handle incoming MQTT messages if needed
            }
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken token) {
        }
    };

    public void sendMessage(View view) {
        String ramInfo = getRAMInfo();
        String storageInfo = getStorageInfo();

        String message = "RAM: " + ramInfo + "\nStorage: " + storageInfo;

        // Update TextViews
        ramTextView.setText(ramInfo);
        storageTextView.setText(storageInfo);

        if (!mqttAsyncClient.isConnected()) {
            connectMqtt();
        } else {
            MqttMessage mqttMessage = new MqttMessage(message.getBytes(StandardCharsets.UTF_8));

            try {
                mqttAsyncClient.publish(TOPIC, mqttMessage);
                Log.d("MQTT", "Message Published: " + message);
            } catch (MqttException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private String getRAMInfo() {
        long totalMemory = Runtime.getRuntime().totalMemory();
        long freeMemory = Runtime.getRuntime().freeMemory();
        return "Total RAM: " + totalMemory + " bytes\nFree RAM: " + freeMemory + " bytes";
    }

    private String getStorageInfo() {
        StatFs statFs = new StatFs(Environment.getDataDirectory().getPath());
        long blockSize = statFs.getBlockSizeLong();
        long totalBlocks = statFs.getBlockCountLong();
        long availableBlocks = statFs.getAvailableBlocksLong();

        long totalSize = totalBlocks * blockSize;
        long availableSize = availableBlocks * blockSize;

        return "Total Storage: " + totalSize + " bytes\nAvailable Storage: " + availableSize + " bytes";
    }

    private void connectMqtt() {
        try {
            mqttAsyncClient = new MqttAsyncClient(broker, clientID, new MemoryPersistence());

            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);
            options.setAutomaticReconnect(true);

            mqttAsyncClient.connect(options, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.d("MQTT", "We are connected");

                    try {
                        mqttAsyncClient.setCallback(mqttCallBack);
                        mqttAsyncClient.subscribe(TOPIC, 0);
                    } catch (MqttException e) {
                        throw new RuntimeException(e);
                    }
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e("MQTT", "We are not connected");
                }
            });

        } catch (MqttException e) {
            throw new RuntimeException(e);
        }
    }
}
