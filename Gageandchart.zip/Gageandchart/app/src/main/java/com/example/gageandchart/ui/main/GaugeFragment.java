package com.example.gageandchart.ui.main;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.ekn.gruzer.gaugelibrary.HalfGauge;
import com.ekn.gruzer.gaugelibrary.Range;
import com.example.gageandchart.R;

import java.util.Random;


public class GaugeFragment extends Fragment {
    private HalfGauge halfGauge;

public GaugeFragment()
{

}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_gauge, container, false);
        halfGauge = view.findViewById((R.id.gauge));
        Range rangeRed = new Range(); //
        rangeRed.setColor(Color.parseColor("#ff0000"));
        rangeRed.setFrom(80);
        rangeRed.setTo(100);
        halfGauge.addRange(rangeRed);

        Range rangeblue = new Range(); //
        rangeblue.setColor(Color.parseColor("#0000ff"));
        rangeblue.setFrom(-20);
        rangeblue.setTo(0);
        halfGauge.addRange(rangeblue);
        halfGauge.addRange(rangeRed);

        halfGauge.setMinValue(-20);
        halfGauge.setMaxValue(100);
        halfGauge.setValue(50);


        // Inflate the layout for this fragment
        Button btn = view.findViewById(R.id.refresh_button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random random = new Random();
                double value = random.nextInt(120)-21;
                halfGauge.setValue(value);
            }
        });
    return view;
    }
}