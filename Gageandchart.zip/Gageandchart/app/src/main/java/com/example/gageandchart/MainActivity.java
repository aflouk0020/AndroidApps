package com.example.gageandchart;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.ekn.gruzer.gaugelibrary.HalfGauge;
import com.ekn.gruzer.gaugelibrary.Range;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private HalfGauge halfGauge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        halfGauge = findViewById(R.id.gauge);
        Range rangeRed = new Range(); //
        rangeRed.setColor(Color.parseColor("#ff0000"));
        rangeRed.setFrom(80);
        rangeRed.setTo(100);
        halfGauge.addRange(rangeRed);

        Range rangeblue = new Range(); //
        rangeblue.setColor(Color.parseColor("#0000ff"));
        rangeblue.setFrom(-20);
        rangeblue.setTo(0);
        halfGauge.addRange(rangeblue);
        halfGauge.addRange(rangeRed);

        halfGauge.setMinValue(-20);
        halfGauge.setMaxValue(100);
        halfGauge.setValue(50);

    }

        public void refresh(View view)
        {
            Random random = new Random();
            double value = random.nextInt(120)-21;
            halfGauge.setValue(value);
        }

    }


