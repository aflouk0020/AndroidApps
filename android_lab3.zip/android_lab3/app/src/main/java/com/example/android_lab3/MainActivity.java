package com.example.android_lab3;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "MyPrefs";
    private static final String KEY_COLOR = "backgroundColor";
    private static final String KEY_ITEMS = "items";

    private ConstraintLayout mainLayout;
    private RadioGroup radioGroup;
    private RadioButton radioYellow, radioWhite;
    private EditText editText;
    private Button buttonNew;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> items;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainLayout = findViewById(R.id.mainLayout);
        radioGroup = findViewById(R.id.radioGroup);
        radioYellow = findViewById(R.id.radioYellow);
        radioWhite = findViewById(R.id.radioWhite);
        editText = findViewById(R.id.editText);
        buttonNew = findViewById(R.id.buttonNew);
        listView = findViewById(R.id.listView);

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Load saved background color for mainLayout
        String savedColor = sharedPreferences.getString(KEY_COLOR, "White");
        if ("Yellow".equals(savedColor)) {
            mainLayout.setBackgroundColor(Color.YELLOW);
            radioYellow.setChecked(true);
        } else {
            mainLayout.setBackgroundColor(Color.WHITE);
            radioWhite.setChecked(true);
        }

        // Load saved items
        Set<String> savedItems = sharedPreferences.getStringSet(KEY_ITEMS, new HashSet<>());
        items = new ArrayList<>(savedItems);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);

        // RadioGroup listener to change background color of mainLayout
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioYellow) {
                mainLayout.setBackgroundColor(Color.YELLOW);
                saveBackgroundColor("Yellow");
            } else if (checkedId == R.id.radioWhite) {
                mainLayout.setBackgroundColor(Color.WHITE);
                saveBackgroundColor("White");
            }
        });

        // Button listener to add new item
        buttonNew.setOnClickListener(v -> {
            String text = editText.getText().toString().trim();
            if (!text.isEmpty()) {
                items.add(text);
                adapter.notifyDataSetChanged();
                editText.setText("");
                saveItems();
            } else {
                Toast.makeText(MainActivity.this, "Please enter text", Toast.LENGTH_SHORT).show();
            }
        });

        // ListView long click listener to remove item
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            items.remove(position);
            adapter.notifyDataSetChanged();
            saveItems();
            return true;
        });
    }

    private void saveBackgroundColor(String color) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_COLOR, color);
        editor.apply();
    }

    private void saveItems() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Set<String> set = new HashSet<>(items);
        editor.putStringSet(KEY_ITEMS, set);
        editor.apply();
    }
}
