package com.example.myapplication;

import androidx.fragment.app.FragmentActivity;
import java.util.Calendar;
import android.os.Bundle;
import android.view.View;

import com.example.myapplication.databinding.ActivityMapsBinding;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    private ActivityMapsBinding binding;

    Marker marker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


//        MapsInitializer.initialize(getApplicationContext(), MapsInitializer.Renderer.LATEST, new OnMapsSdkInitializedCallback() {
//            @Override
//            public void onMapsSdkInitialized(@NonNull MapsInitializer.Renderer renderer) {
//
//            }
//        });
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */


        @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera

        LatLng tus = new LatLng(53.417962, -7.903544);
        CameraPosition pos = new CameraPosition.Builder().target(tus).zoom(13).bearing(0).tilt(0).build();
        marker = mMap.addMarker(new MarkerOptions().position(tus).title("Marker"));
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(pos));
            setMapStyleByMonthAndHour();
    }
    public void setMapStyleByMonthAndHour() {
        Calendar calendar = Calendar.getInstance();
        int currentHour = calendar.get(Calendar.HOUR_OF_DAY);
        int currentMonth = calendar.get(Calendar.MONTH) + 1; // Adjust month to be 1-based

        int[][] nightStyleRanges = {
                {1, 8, 17},
                {2, 7, 18},
                {3, 7, 19},
                {4, 6, 20},
                {5, 6, 21},
                {6, 5, 22},
                {7, 5, 23},
                {8, 6, 22},
                {9, 6, 21},
                {10, 7, 20},
                {11, 7, 18},
                {12, 8, 17}
        };

        int[] selectedStyle = findMatchingStyle(currentMonth, currentHour, nightStyleRanges);

        if (selectedStyle != null) {
            int month = selectedStyle[0];
            int startHour = selectedStyle[1];
            int endHour = selectedStyle[2];

            if (currentHour <= startHour || currentHour >= endHour)
            {
                mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.night_style));
            }
            else
            {
                mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.dark_style));
            }
        }
        else
        {
            mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.aubergine_style));
        }
    }

    private int[] findMatchingStyle(int currentMonth, int currentHour, int[][] nightStyleRanges) {
        for (int[] range : nightStyleRanges)
        {
            int month = range[0];
            int startHour = range[1];
            int endHour = range[2];

            if (currentMonth == month)
            {
                return range;
            }
        }
        return null;
    }


    public void setStandard(View view){
        if(mMap != null) {
            mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.standard_style));

        }
    }
    public void setSilver(View view) {
        if (mMap != null){
            mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this,R.raw.silver_style));

        }
    }

    public void setRetro(View view) {
        if (mMap != null){
            mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.retro_style));
        }
    }

    public void setDark(View view) {
        if (mMap != null){
            mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.dark_style));
        }
    }

    public void setNight(View view) {
        if (mMap != null){
            mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.night_style));

        }
    }

    public void setAubergine(View view) {
        if (mMap != null){
            mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this,R.raw.aubergine_style));
        }
    }


}