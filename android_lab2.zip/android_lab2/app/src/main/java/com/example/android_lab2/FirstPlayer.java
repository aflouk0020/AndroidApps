package com.example.android_lab2;

import android.os.Bundle;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;

public class FirstPlayer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_player);

        // Receive text from Intent
        String receivedText = getIntent().getStringExtra("TEXT_KEY");

        // Set received text in TextView (ensure TextView ID matches layout XML)
        TextView textView = findViewById(R.id.textView2); // Use textView2 as defined in XML
        if (receivedText != null) {
            textView.setText(receivedText);
        }

        // Set up YouTubePlayerView and add lifecycle observer
        YouTubePlayerView youTubePlayerView = findViewById(R.id.youtube_player_view);
        getLifecycle().addObserver(youTubePlayerView);

        // Add listener to YouTubePlayerView to play video
        youTubePlayerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                String videoId = "bdjolSYgcGk"; // Replace with desired video ID
                youTubePlayer.loadVideo(videoId, 0);
            }
        });
    }
}
