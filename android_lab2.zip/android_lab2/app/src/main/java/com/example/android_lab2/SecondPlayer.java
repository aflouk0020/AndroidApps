package com.example.android_lab2;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;

public class SecondPlayer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_player); // Set your layout here

        // Retrieve the text passed from the previous activity
        String receivedText = getIntent().getStringExtra("TEXT_KEY");

        // Display the received text in the TextView if available
        TextView textView = findViewById(R.id.textView3); // Use the new ID for the TextView
        if (receivedText != null) {
            textView.setText(receivedText);
        }

        YouTubePlayerView youTubePlayerView = findViewById(R.id.youtube_player_view_second);
        getLifecycle().addObserver(youTubePlayerView);

        youTubePlayerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                String videoId = ""; // Placeholder for your video ID
                youTubePlayer.loadVideo(videoId, 0);
            }
        });
    }
}
