package com.example.android_lab2;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {

    private String imageName = "https://a57.foxsports.com/stage-statics.foxsports.com/stage.foxsports.com/content/uploads/2024/07/1280/854/argentina1.jpg?ve=1&tl=1";
    private ImageView imageView;
    private CardView cardView1, cardView2, cardView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Set the content view (your layout XML)

        imageView = findViewById(R.id.imageView1);
        cardView1 = findViewById(R.id.cardView1);
        cardView2 = findViewById(R.id.cardView2);
        cardView3 = findViewById(R.id.cardView3);

        // Load image with Glide
        Glide.with(this).load(imageName).into(imageView);

        // Set click listener for cardView1
        cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open FirstPlayer activity and pass text
                Intent intent = new Intent(MainActivity.this, FirstPlayer.class);
                intent.putExtra("TEXT_KEY", "Text for First Player");
                startActivity(intent);
            }
        });

        // Set click listener for cardView2
        cardView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open SecondPlayer activity and pass text
                Intent intent = new Intent(MainActivity.this, SecondPlayer.class);
                intent.putExtra("TEXT_KEY", "Text for Second Player");
                startActivity(intent);
            }
        });

        // Set click listener for cardView3
        cardView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open ThirdPlayer activity and pass text
                Intent intent = new Intent(MainActivity.this, ThirdPlayer.class);
                intent.putExtra("TEXT_KEY", "Text for Third Player");
                startActivity(intent);
            }
        });
    }
}
